#ifndef REPORTS_H_INCLUDED
#define REPORTS_H_INCLUDED
#include "Helpers.h"

void ArtisteReport(){

}

void FoundationReport(){

}

void BookingReport(){

}

void GeneralReport(){

}

void GenerateInvoice(){

}

#endif // REPORTS_H_INCLUDED
